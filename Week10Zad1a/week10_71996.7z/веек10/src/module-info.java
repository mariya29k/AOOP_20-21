module com.geometry.types {
    exports com.geometry.types;
}