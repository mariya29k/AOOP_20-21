package com.geometry.types;

public abstract class Shape implements Comparable{

}
